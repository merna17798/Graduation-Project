package com.example.servo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;

import java.net.*;
import java.io.*;

public class MainActivity extends AppCompatActivity {
    //UI Element
    Button btnforward;
    Button btnbackward;
    Button btnleft;
    Button btnright;
    Button btnstop;
    Button btnstart;
    //DatabaseReference reference;
    EditText txtAddress;
    TextView rfid;
    Socket myAppSocket = null;
    public static String wifiModuleIp = "";
    public static int wifiModulePort = 0;
    public static String CMD = "0";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


            btnforward = (Button) findViewById(R.id.button2);
            btnbackward = (Button) findViewById(R.id.button3);
            btnleft = (Button) findViewById(R.id.button);
            btnright = (Button) findViewById(R.id.button5);
            btnstart = (Button) findViewById(R.id.start);
            btnstop = (Button) findViewById(R.id.stop);

           txtAddress = (EditText) findViewById(R.id.ipAddress);
           rfid=(TextView) findViewById(R.id.textView) ;


           //create to actions for two buttons
           btnforward.setOnClickListener(new View.OnClickListener() {
               @Override
               public void onClick(View v) {
                   getIPandPort();
                   CMD = "forward";
                   Socket_AsyncTask cmd_increase_servo = new Socket_AsyncTask();
                   cmd_increase_servo.execute();
               }
           });
            btnbackward.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getIPandPort();
                    CMD = "backward";
                    Socket_AsyncTask cmd_increase_servo = new Socket_AsyncTask();
                    cmd_increase_servo.execute();
                    rfid.setText("742569293289");

                }
            });
        btnleft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getIPandPort();
                CMD = "left";
                Socket_AsyncTask cmd_increase_servo = new Socket_AsyncTask();
                cmd_increase_servo.execute();
            }
        });
        btnright.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getIPandPort();
                CMD = "right";
                Socket_AsyncTask cmd_increase_servo = new Socket_AsyncTask();
                cmd_increase_servo.execute();
            }
        });
        btnstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getIPandPort();
                CMD = "start";
                Socket_AsyncTask cmd_increase_servo = new Socket_AsyncTask();
                cmd_increase_servo.execute();
            }
        });
        btnstop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getIPandPort();
                CMD = "stop";
                Socket_AsyncTask cmd_increase_servo = new Socket_AsyncTask();
                cmd_increase_servo.execute();
            }
        });


        //Toast.makeText(MainActivity.this , "Firebase connection success" ,Toast.LENGTH_LONG).show();



    }
    //method to get ip address and port number from textbox
    public void getIPandPort()
    {
        String iPandPort = txtAddress.getText().toString();
        Log.d("MYTEST","IP String: "+ iPandPort);
        String temp[]= iPandPort.split(":");
        wifiModuleIp = temp[0];
        wifiModulePort = Integer.valueOf(temp[1]);
        Log.d("MY TEST","IP:" +wifiModuleIp);
        Log.d("MY TEST","PORT:"+wifiModulePort);
    }
    //helper task for tcp/ip protocol interface,from this method we can send command to raspbry over wifi
    public class Socket_AsyncTask extends AsyncTask<Void,Void,Void>
    {
        Socket socket;

        @Override
        protected Void doInBackground(Void... params){
            try{
                InetAddress inetAddress = InetAddress.getByName(MainActivity.wifiModuleIp);
                socket = new java.net.Socket(inetAddress,MainActivity.wifiModulePort);
                DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
                dataOutputStream.writeBytes(CMD);
                dataOutputStream.close();
                socket.close();
            }catch (UnknownHostException e){e.printStackTrace();}catch (IOException e){e.printStackTrace();}
            return null;
        }
    }
}